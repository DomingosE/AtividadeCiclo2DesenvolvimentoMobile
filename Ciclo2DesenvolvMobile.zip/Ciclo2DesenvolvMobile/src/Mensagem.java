import java.util.*;

/**
 * 
 */
public abstract class Mensagem {
	
	/**
	 * Default Constructor
	 */
	public Mensagem() {
	}
	
	/**
	 * 
	 */
	private Contato destinatario;

}