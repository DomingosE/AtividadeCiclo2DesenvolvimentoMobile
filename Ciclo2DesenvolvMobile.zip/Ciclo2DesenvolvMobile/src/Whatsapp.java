import java.util.*;

/**
 * 
 */
public class Whatsapp {
	
	/**
	 * Default Constructor
	 */
	public Whatsapp() {
	}
	
	/**
	 * 
	 */
	private Contato contato;
	
	/**
	 * 
	 */
	private Mensagem mensagem;	

}