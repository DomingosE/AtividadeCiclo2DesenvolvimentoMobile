import java.util.*;

/**
 * 
 */
public class Contato {
	
	/**
	 * Default Constructor
	 */
	public Contato() {
	}
	
	/**
	 * 
	 */
	private String nome;
	
	/**
	 * 
	 */
	private String celular;	

}